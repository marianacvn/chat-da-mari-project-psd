from configuracao import *
from cadastro_usuario import*
import threading
import socket


class Cliente():

    def __init__(self, usuario, servidor, porta):

        self.cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ADDR = (servidor, int(porta))
        self.cliente.connect(ADDR)
        self.ativo = True

        self.name = usuario
        self.enviarMensagem(self.name)

        self.thread_recv = threading.Thread(target=self.receberMensagem, args=())
        self.thread_recv.start()

        self.main_loop()


    def main_loop(self):
        while (self.ativo):
            try:
                msg = str(input())

                if (msg != "" and msg != DISCONNECT_MESSAGE):
                    self.enviarMensagem(msg)
                    msg = ""
                else:
                    self.desconectado()
                    self.ativo = False
            except:
                self.desconectado()

    def escolher_comando(self):
        pass

    def enviarMensagem(self, msg):
            try:
                mensagem, enviar_tamanho = codificarMensagem(msg)
                self.cliente.send(enviar_tamanho)
                self.cliente.send(mensagem)

                if (msg == DISCONNECT_MESSAGE):
                    self.desconectado()

            except:
                print("Falha na conexão")
                self.ativo = False


    def receberMensagem(self):

        while self.ativo:
            try:
                msg_tamanho = self.cliente.recv(HEADER).decode(FORMAT)
                if msg_tamanho:
                    msg_tamanho = int(msg_tamanho)
                    msg = self.cliente.recv(msg_tamanho).decode(FORMAT)
                    print(msg)
            except:
                self.ativo = False


    def desconectado(self):

        print("Tchau...")
        self.cliente.close()
        self.ativo = False
        print("[Conexão Finalizada]")


def codificarMensagem(msg):
    mensagem = str(msg).encode(FORMAT)
    msg_tamanho = len(mensagem)
    enviar_tamanho = str(msg_tamanho).encode(FORMAT)
    enviar_tamanho += b' ' * (HEADER - len(enviar_tamanho))
    return mensagem, enviar_tamanho




if(__name__ == "__main__"):
    print("#############  Chat da Mari #############\n")

    usuario = input("Insira seu apelido: ")

    if cadastrar_usuario(usuario) :
        c = Cliente(usuario, SERVER, PORT)
    else:
        print(f'Apelido {usuario} já existe')
