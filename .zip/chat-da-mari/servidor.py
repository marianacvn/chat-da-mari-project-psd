import threading
import socket
from datetime import datetime

from configuracao import *


class Servidor():

    def __init__(self):

        self.servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        self.servidor.bind(ADDR)

        self.conectado = []
        self.usuario = []

        self.ativo = True

        print("#############  Chat da Mari #############\n")
        print("Inicializando servidor...")

        self.servidor.listen()
        print(f"[LISTENING] Server is listening on {SERVER} port {PORT}")

        self.assinar()

    def assinar(self):
        while self.ativo:
            try:
                conexao, addr = self.servidor.accept()

                usuario = ''
                tamanho_usuario = int(conexao.recv(HEADER).decode(FORMAT))
                usuario = conexao.recv(tamanho_usuario).decode(FORMAT)

                if len(self.usuario) != 0:
                    for user in self.usuario:
                        if usuario == user:
                            print('usuario ja existe')
                             

                self.usuario.append(usuario)
                self.conectado.append(conexao)



                thread = threading.Thread(target=self.atualizar, args=(conexao, usuario))
                thread.start()

                msg = f"{usuario} entrou no chat. Quantidade de Usuários {len(self.conectado)}."
                self.mensagemServidor(msg)

            except:
                print("[CLOSING] Server is closing.")
                self.servidor.close()
                self.ativo = False
                return


    def cancelarAssinatura(self, conexao, usuario):
        index = self.conectado.index(conexao)
        self.usuario.pop(index)
        self.conectado.remove(conexao)

        conexao.close()

        _data_atual = data_atual()
        msg = (f"{usuario} saiu *-* ({_data_atual}).")
        self.mensagemServidor(msg)


    def atualizar(self, conexao, usuario):
        cliente_ativo = True
        while cliente_ativo:
            try:
                tamanho_mensagem = conexao.recv(HEADER).decode(FORMAT)
                if tamanho_mensagem:
                    tamanho_mensagem = int(tamanho_mensagem)
                    msg = conexao.recv(tamanho_mensagem).decode(FORMAT)

                    if msg == DISCONNECT_MESSAGE:
                        self.cancelarAssinatura(conexao, usuario)
                        cliente_ativo = False
                        return

                    self.mensagemPublica(msg, conexao, usuario)
                    msg = ''


            except:
                self.cancelarAssinatura(conexao, usuario)
                cliente_ativo = False
                return

    def defineOp(self, msg, conexao, usuario):
        if ('op' == NEW_MESSAGE):
            self.mensagemPublica(msg, conexao, usuario)

        elif ('op' == 1):
            pass

    def mensagemServidor(self, msg):

        print(msg)

        mensagem, enviar_tamanho = codificarMensagem(msg)

        for cliente in self.conectado:
            cliente.send(enviar_tamanho)
            cliente.send(mensagem)

    def mensagemPublica(self, msg, conexao, usuario):

        _data_atual = data_atual()

        msgTodos = (f"{usuario} ({_data_atual}): {msg}")
        msgMinha = (f"Eu ({_data_atual}): {msg}")
        print(msgTodos)

        mensagem, enviar_tamanho = codificarMensagem(msgTodos)
        mensagemMinha, enviar_tamanhoMinha = codificarMensagem(msgMinha)

        for cliente in self.conectado:
            if(cliente != conexao):
                cliente.send(enviar_tamanho)
                cliente.send(mensagem)

            else:
                cliente.send(enviar_tamanhoMinha)
                cliente.send(mensagemMinha)


def data_atual():
    data_atual = datetime.now()
    hora_atual = data_atual.strftime("%H:%M:%S")
    return(f"{data_atual.day}/{data_atual.month}/{data_atual.year} - {hora_atual}")

def codificarMensagem(msg):
    mensagem = str(msg).encode(FORMAT)
    tamanho_mensagem = len(mensagem)
    enviar_tamanho = str(tamanho_mensagem).encode(FORMAT)
    enviar_tamanho += b' ' * (HEADER - len(enviar_tamanho))
    return mensagem, enviar_tamanho

if ("__main__" == __name__):
    s = Servidor()
